let campoX = 0;
let cidadeX = 600;
let caminhaoX = 50;
let velocidade = 2;
let mensagem = "";
let velocidadeSlider;
let pontuacao = 0;

let arvores = [
  { x: 400, recolhida: false },
  { x: 500, recolhida: false },
  { x: 580, recolhida: false },
  { x: 680, recolhida: false },
  { x: 760, recolhida: false }
];

function setup() {
  createCanvas(800, 400);
  velocidadeSlider = createSlider(1, 10, 2);
  velocidadeSlider.position(10, 10);
  velocidadeSlider.style('width', '200px');
}

function draw() {
  background(135, 206, 235);

  velocidade = velocidadeSlider.value();
  
  mostrarInstrucoes();
  drawCampo();
  drawCidade();
  drawCaminhao();
  displayVelocidade();
  displayMensagem();
  displayPontuacao();

  caminhaoX += velocidade;
  if (caminhaoX > width) {
    caminhaoX = -50;
  }

  for (let arvore of arvores) {
    if (!arvore.recolhida && caminhaoX + 50 > arvore.x && caminhaoX < arvore.x + 50) {
      arvore.recolhida = true;
      pontuacao++;
      mensagem = "Árvore recolhida!";
      break;
    }
  }
}

function drawCampo() {
  fill(34, 139, 34);
  rect(0, 250, width, height - 250);

  // Árvores plantadas
  for (let arvore of arvores) {
    if (!arvore.recolhida) {
      fill(139, 69, 19);
      rect(arvore.x, 200, 20, 50);
      fill(34, 139, 34);
      ellipse(arvore.x + 10, 180, 60, 60);
    }
  }

  fill(255, 215, 0);
  rect(50, 270, 150, 20); // Plantação de milho

  // Sol
  fill(255, 204, 0);
  ellipse(100, 50, 80, 80);
}

function drawCidade() {
  fill(192, 192, 192);
  rect(cidadeX, 0, 200, height);

  fill(255, 255, 255);
  for (let i = 0; i < 5; i++) {
    for (let j = 0; j < 3; j++) {
      rect(cidadeX + 30 + i * 40, j * 60 + 40, 30, 30);
    }
  }
}

function drawCaminhao() {
  fill(255, 69, 0);
  rect(caminhaoX, 280, 50, 30);
  fill(0);
  ellipse(caminhaoX + 10, 310, 20, 20);
  ellipse(caminhaoX + 40, 310, 20, 20);
}

function displayVelocidade() {
  fill(0);
  textSize(16);
  textAlign(RIGHT);
  text("Velocidade: " + velocidade, width - 20, 30);
}

function mostrarInstrucoes() {
  fill(0);
  textSize(20);
  textAlign(CENTER);
  text("Use o slider para ajustar a velocidade.", width / 2, 130);
  textSize(14);
  text("Clique no campo para plantar novas árvores.", width / 2, 150);
}

function displayMensagem() {
  if (mensagem !== "") {
    fill(255, 0, 0);
    textSize(16);
    textAlign(CENTER);
    text(mensagem, width / 2, 50);
  }
}

function displayPontuacao() {
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text("Pontuação: " + pontuacao, 20, 40);
}

function mousePressed() {
  // Só planta árvores no campo (parte de baixo)
  if (mouseY > 200 && mouseY < height) {
    arvores.push({ x: mouseX - 10, recolhida: false });
    mensagem = "Nova árvore plantada!";
  }
}



 